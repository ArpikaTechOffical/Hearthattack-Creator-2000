Don't worry, this was just a harmless prank! Your PC is Fine!
Comands used:
dir (cmd)
cd (cmd)
msgbox (vbs)

Made by ArpikaTech
YouTube:ArpikaTech